# Basic Naming
1.  Java Class Naming
    -   Package : __모두 소문자__ 로 작성한다.
        >   EX > `com.sun.eng`
    -   Classes : __대문자로 시작__ 하며, __명사형__ 이다.
        >   EX > `class Raster`
    -   Interface : __대문자로 시작__ 하며, __형용사형__ 이다.
        >   EX > `interface Stroing`
    -   Method : __동사형__ 이며, __소문자로 시작__ 한다.
        >   EX > `run()` / `getBackground()`
    -   Variables : __소문자로 시작__ 한다.
        >   EX > `int i` / `float myWidth`
    -   Constant : __모두 대문자__ 로 작성한다.
        >   EX > `static final int MIN_WIDTH=4`
-   Camel Case : 소문자로 시작할 경우 적용되는 작성 방식
    이름이 __두 가지 단어__ 로 혼합되어 있다면 뒤의 단어는 대문자로 시작한다.

2.  XML Naming
    -   __대소문자를 구분__ 한다.
    -   `문자` 혹은 `_(Underscore)`로 시작한다.
    -   공백은 포함시키지 않는다.

3.  Variable Naming
    -   Pascal Case : __대문자로 시작__ 하고 새로운 단어도 대문자로 작성한다.
        >   EX > UtilityBox
    -   Camel Case : __소문자로 시작__ 하고 새로운 단어는 대문자로 작성한다.
        >   EX > utilityBox
    -   GNU Naming Convention : __모두 소문자__ 를 사용하고 __복합어 사이를 '_'를 사용__ 하여 연결한다.
        Linux 프로젝트에서 주로 사용된다.
        >   EX > gtk_widget_activate
    -   Hungarian Notaiton : 윈도우즈 프로그래밍에서 주로 사용된다.
        >   EX > g_bTrue
        >   g : 전역변수 ( 'm'은 멤버변수를 의미 )
        >   _ : 전역변수(g) 또는 멤버변수(m) 경우에는 '_'를 다음에 적는다.
        >   b : Boolean타입을 의미
        >   True : 의미있는 이름

        >   EX > nCnt
        >   전역변수 혹은 멤버변수가 아니다.
        >   n : 자연수(또는 'i')
        >   의미있는 이름이 길 경우 자음만을 사용한다.
        
# Basic Widget
