package com.example.calculatorapplication;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class CalculatorFragment extends Fragment implements View.OnClickListener {
    private View view;
    private TextView mCalcTextView;
    private Button mNumberButton_0;
    private Button mNumberButton_1;
    private Button mNumberButton_2;
    private Button mNumberButton_3;
    private Button mNumberButton_4;
    private Button mNumberButton_5;
    private Button mNumberButton_6;
    private Button mNumberButton_7;
    private Button mNumberButton_8;
    private Button mNumberButton_9;

    private Button mCalcButton_Add;
    private Button mCalcButton_Subt;
    private Button mCalcButton_Mult;
    private Button mCalcButton_Div;

    private Button mCalcButton_Result;
    private Button mCalcButton_Reset;

    private String mArithmeticOP="";

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
    }
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        view = inflater.inflate(R.layout.calculator_fragment, null);
        init(view);
        return view;
    }

    private void init(View view) {
        mCalcTextView = (TextView)view.findViewById(R.id.Calc_TextView);
        buttonBind(view);
    }

    private void buttonBind(View view) {
        mNumberButton_0 = (Button)view.findViewById(R.id.calc_Button_0);
        mNumberButton_0.setOnClickListener(this);
        mNumberButton_1 = (Button)view.findViewById(R.id.calc_Button_1);
        mNumberButton_1.setOnClickListener(this);
        mNumberButton_2 = (Button)view.findViewById(R.id.calc_Button_2);
        mNumberButton_2.setOnClickListener(this);
        mNumberButton_3 = (Button)view.findViewById(R.id.calc_Button_3);
        mNumberButton_3.setOnClickListener(this);
        mNumberButton_4 = (Button)view.findViewById(R.id.calc_Button_4);
        mNumberButton_4.setOnClickListener(this);
        mNumberButton_5 = (Button)view.findViewById(R.id.calc_Button_5);
        mNumberButton_5.setOnClickListener(this);
        mNumberButton_6 = (Button)view.findViewById(R.id.calc_Button_6);
        mNumberButton_6.setOnClickListener(this);
        mNumberButton_7 = (Button)view.findViewById(R.id.calc_Button_7);
        mNumberButton_7.setOnClickListener(this);
        mNumberButton_8 = (Button)view.findViewById(R.id.calc_Button_8);
        mNumberButton_8.setOnClickListener(this);
        mNumberButton_9 = (Button)view.findViewById(R.id.calc_Button_9);
        mNumberButton_9.setOnClickListener(this);

        mCalcButton_Add = (Button)view.findViewById(R.id.calc_Button_Add);
        mCalcButton_Add.setOnClickListener(this);
        mCalcButton_Subt = (Button)view.findViewById(R.id.calc_Button_Subt);
        mCalcButton_Subt.setOnClickListener(this);
        mCalcButton_Mult = (Button)view.findViewById(R.id.calc_Button_Multi);
        mCalcButton_Mult.setOnClickListener(this);
        mCalcButton_Div = (Button)view.findViewById(R.id.calc_Button_Div);
        mCalcButton_Div.setOnClickListener(this);

        mCalcButton_Result = (Button)view.findViewById(R.id.calc_Button_Result);
        mCalcButton_Result.setOnClickListener(this);
        mCalcButton_Reset = (Button)view.findViewById(R.id.calc_Button_Reset);
        mCalcButton_Reset.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.calc_Button_0 :
                mArithmeticOP += "0";
                break;
            case R.id.calc_Button_1 :
                mArithmeticOP += "1";
                break;
            case R.id.calc_Button_2 :
                mArithmeticOP += "2";
                break;
            case R.id.calc_Button_3 :
                mArithmeticOP += "3";
                break;
            case R.id.calc_Button_4 :
                mArithmeticOP += "4";
                break;
            case R.id.calc_Button_5 :
                mArithmeticOP += "5";
                break;
            case R.id.calc_Button_6 :
                mArithmeticOP += "6";
                break;
            case R.id.calc_Button_7 :
                mArithmeticOP += "7";
                break;
            case R.id.calc_Button_8 :
                mArithmeticOP += "8";
                break;
            case R.id.calc_Button_9 :
                mArithmeticOP += "9";
                break;
            case R.id.calc_Button_Add :
                mArithmeticOP += "+";
                break;
            case R.id.calc_Button_Subt :
                mArithmeticOP += "-";
                break;
            case R.id.calc_Button_Multi :
                mArithmeticOP += "*";
                break;
            case R.id.calc_Button_Div :
                mArithmeticOP += "/";
                break;
            case R.id.calc_Button_Result :
                break;
            case R.id.calc_Button_Reset :
                mArithmeticOP = "";
                break;
        }
        mCalcTextView.setText(mArithmeticOP);
        if(v.getId() == R.id.calc_Button_Result){
            arithmeticOperate(mArithmeticOP);
        }
    }

    private void arithmeticOperate(String mArithmeticOP) {
        int index = 0;
        String value1;
        String value2;
        int result;

        if(mArithmeticOP.contains("+")){
            index = mArithmeticOP.indexOf("+");
            value1 = mArithmeticOP.substring(0, index);
            value2 = mArithmeticOP.substring(index+1);
            result = Integer.parseInt(value1) + Integer.parseInt(value2);
            mCalcTextView.setText(Integer.toString(result));
        }
        else if(mArithmeticOP.contains("-")){
            index = mArithmeticOP.indexOf("-");
            value1 = mArithmeticOP.substring(0, index);
            value2 = mArithmeticOP.substring(index+1);
            result = Integer.parseInt(value1) - Integer.parseInt(value2);
            mCalcTextView.setText(Integer.toString(result));
        }
        else if(mArithmeticOP.contains("*")){
            index = mArithmeticOP.indexOf("*");
            value1 = mArithmeticOP.substring(0, index);
            value2 = mArithmeticOP.substring(index+1);
            result = Integer.parseInt(value1) * Integer.parseInt(value2);
            mCalcTextView.setText(Integer.toString(result));
        }
        else if(mArithmeticOP.contains("/")){
            index = mArithmeticOP.indexOf("/");
            value1 = mArithmeticOP.substring(0, index);
            value2 = mArithmeticOP.substring(index+1);
            result = Integer.parseInt(value1) / Integer.parseInt(value2);
            mCalcTextView.setText(Integer.toString(result));
        }
    }
}
