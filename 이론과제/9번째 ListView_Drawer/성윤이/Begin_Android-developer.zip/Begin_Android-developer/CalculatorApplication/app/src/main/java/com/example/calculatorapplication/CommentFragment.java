package com.example.calculatorapplication;

import android.media.Image;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class CommentFragment extends Fragment implements View.OnClickListener {
    private View mView;
    private EditText mCommentEditText;
    private ImageButton mPlusButton;

    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;

    ArrayList<String> mList = new ArrayList<>();

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        mView = inflater.inflate(R.layout.comment_fragment, null);

        viewInit(mView);

        return mView;
    }

    private void viewInit(View mView) {
        mCommentEditText = (EditText)mView.findViewById(R.id.CommentFragment_EditText);
        mCommentEditText.setText("Enter a Words");
        mPlusButton = (ImageButton)mView.findViewById(R.id.CommentFragment_PlusButton);
        mPlusButton.setOnClickListener(this);

        mRecyclerView = (RecyclerView)mView.findViewById(R.id.CommentFragment_RecyclerView);
        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);
    }

    @Override
    public void onClick(View v) {   // when plusbutton is clicked
        mList.add(mCommentEditText.getText().toString());
        mAdapter = new CommentRecyclerViewAdapter(mList);
        mRecyclerView.setAdapter(mAdapter);
    }
}
