package com.example.calculatorapplication;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ListView mDrawerListView = null;
    private Fragment fragment = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        drawerInit();
    }

    private void drawerInit() {
        final String[] items = {"Comment", "Calculator"};
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, items);

        mDrawerListView = (ListView)findViewById(R.id.Drawer_Menulist);
        mDrawerListView.setAdapter(adapter);
        mDrawerListView.setOnItemClickListener(new ListView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch(position){
                    case 0 :    // Comment
                        fragment = new CommentFragment();
                        break;
                    case 1 :    // Calculator
                        fragment = new CalculatorFragment();
                        break;
                }
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.FrameLayout, fragment);
                fragmentTransaction.commit();

                DrawerLayout drawer = findViewById(R.id.Drawer_Layout);
                drawer.closeDrawer(Gravity.LEFT);   // Close Drawer
            }
        });
    }
}
