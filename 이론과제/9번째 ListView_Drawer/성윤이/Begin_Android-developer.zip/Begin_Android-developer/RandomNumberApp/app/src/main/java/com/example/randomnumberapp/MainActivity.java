package com.example.randomnumberapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public static String count = "0";
    TextView board;
    Button toastButton;
    Button countButton;
    Button randomButton;
    String sfpoint = "0";
    private SharedPreferences pref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        board = (TextView) findViewById(R.id.textView);
        SharedPreferences sf = getSharedPreferences(sfpoint, 0);
        board.setText(count);

        Button.OnClickListener onClickListener = new Button.OnClickListener(){
            @Override
            public void onClick(View v) {
                TextView board = (TextView) findViewById(R.id.textView);
                switch(v.getId()){
                    case R.id.button :  // toastButton
                        board.setText(count);
                        break;
                    case R.id.button2 : // countButton
                        int temp_int = Integer.parseInt(count);
                        temp_int++;
                        count = Integer.toString(temp_int);
                        break;
                    case R.id.button3 :
                        Intent intent = new Intent(MainActivity.this, PrintRandomNum.class);
                        startActivity(intent);
                        break;
                }
            }
        };
        toastButton = (Button) findViewById(R.id.button);
        toastButton.setOnClickListener(onClickListener);
        countButton = (Button) findViewById(R.id.button2);
        countButton.setOnClickListener(onClickListener);
        randomButton = (Button) findViewById(R.id.button3);
        randomButton.setOnClickListener(onClickListener);
    }
    protected void onStop() {
        super.onStop();
        SharedPreferences sf = getSharedPreferences(sfpoint, 0);
        SharedPreferences.Editor editor = sf.edit();
        String str = board.getText().toString();
        editor.putString("0", str);
        editor.commit();
    }
}