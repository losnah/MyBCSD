package com.example.randomnumberapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.Random;

import static com.example.randomnumberapp.MainActivity.*;

public class PrintRandomNum extends AppCompatActivity {
    TextView printText;
    String text = "Random Number between 0 and " + count;
    Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_print_random_num);
        printText = (TextView) findViewById(R.id.textView2);
        printText.setText(text);

        printText = (TextView) findViewById(R.id.textView3);
        int temp_int = Integer.parseInt(count);
        printText.setText(Integer.toString(random.nextInt(temp_int)));
    }
}
