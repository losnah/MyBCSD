package com.example.randomnumberapp2;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    public static int mCountNumber;
    private int mClickCount=0;

    private ImageButton mToastButton;
    public  ImageButton mCountButton;
    private ImageButton mRandomButton;

    private MainFragment mainFragment = new MainFragment();
    private PrintRandomNumberFragment printRandomNumFragment = new PrintRandomNumberFragment();

    private Intent mServiceIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mServiceIntent = new Intent(getApplicationContext(), MainService.class);
        startService(mServiceIntent);
        init();
    }

    private void createNotification() {
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this, "default")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("Fragment")
                .setContentText("Print-RandomNumber");
        NotificationManager notificationManager = (NotificationManager)this.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager.createNotificationChannel(new NotificationChannel("default", "기본 채널", NotificationManager.IMPORTANCE_DEFAULT));
        }
        mBuilder.setProgress(100, 0, true);
        notificationManager.notify(1, mBuilder.build());
    }

    private void init(){
        mCountNumber = 0;

        mToastButton = findViewById(R.id.ToastButton);
        mCountButton = findViewById(R.id.CountButton);
        mRandomButton = findViewById(R.id.RandomButton);

        mToastButton.setOnClickListener(this);
        mCountButton.setOnClickListener(this);
        mRandomButton.setOnClickListener(this);

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.contents, mainFragment);
        fragmentTransaction.commit();
    }

    public void fragmentReset(){
        mainFragment.printNumber(0);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.ToastButton :
                onClickToastButton();
                break;
            case R.id.CountButton :
                onClickCountButton();
                break;
            case R.id.RandomButton :
                onClickRandomButton();
                break;
            default :
                return;
        }
    }

    private void onClickRandomButton() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        mClickCount++;
        if(mClickCount%2 == 0){
            // 짝수번 클릭할 경우 메인프레그먼트로 돌아옴
            NotificationManagerCompat.from(this).cancel(1);

            fragmentTransaction.replace(R.id.contents, mainFragment);
            fragmentTransaction.commit();
        }
        else{
            // 홀수번 클릭할 경우 랜덤넘버출력 프래그먼트로 돌아옴
            createNotification();

            fragmentTransaction.replace(R.id.contents, printRandomNumFragment);
            fragmentTransaction.commit();
        }
    }

    private void onClickCountButton() {
        mainFragment.printNumber(++mCountNumber);
    }

    private void onClickToastButton() {
        DialogFragment alertDialog = new ToastDialog();
        alertDialog.show(getSupportFragmentManager(), "Null");
    }

    public void exitApp() {
        NotificationManagerCompat.from(this).cancel(1);
        stopService(mServiceIntent);
        finish();
    }
}