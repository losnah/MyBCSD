package com.example.randomnumberapp2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Random;

public class PrintRandomNumberFragment extends Fragment implements View.OnClickListener {
    private TextView textView;
    private TextView numberView;
    private Random random = new Random();
    private ImageButton mExitButton;

    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.print_randomnumber_fragment, null);
        init(view);
        mExitButton = view.findViewById(R.id.ExitButton);
        mExitButton.setOnClickListener(this);
        return view;
    }
    public void init(View view){
        textView = (TextView)view.findViewById(R.id.print_text);
        textView.setText("Here is the Random Number between 0 and " + Integer.toString(MainActivity.mCountNumber));
        numberView = (TextView)view.findViewById(R.id.print_randomnumber);
        numberView.setText(Integer.toString(random.nextInt(MainActivity.mCountNumber+1)));
    }

    @Override
    public void onClick(View v) {
        ((MainActivity)getActivity()).exitApp();
    }
}