package com.example.randomnumberapp2;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;

public class MainService extends Service {
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    public void onCreate(){
        Log.d("[Test]", "onCreate");
        super.onCreate();
    }
    public int onStartCommand(Intent intent, int flags, int startId){
        Log.d("[Test]", "onStartCommand");
        return super.onStartCommand(intent, flags, startId);
    }
    public void onDestroy(){
        Log.d("[Test]", "onDestroy");
        super.onDestroy();
    }
}
