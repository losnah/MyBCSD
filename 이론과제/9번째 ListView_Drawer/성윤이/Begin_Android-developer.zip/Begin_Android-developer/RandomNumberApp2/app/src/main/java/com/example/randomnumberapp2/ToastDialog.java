package com.example.randomnumberapp2;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.widget.Toast;

public class ToastDialog extends DialogFragment {
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage(R.string.AlertDialog_Text)
                .setPositiveButton(R.string.AlertDialog_Yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ((MainActivity)getActivity()).mCountNumber=0;
                        ((MainActivity)getActivity()).fragmentReset();
                    }
                })
                .setNeutralButton(R.string.AlertDialog_Neutral, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getActivity() , Integer.toString(MainActivity.mCountNumber), Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(R.string.AlertDialog_No, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dismiss();
                    }
                });
        return builder.create();
    }

}
