package com.example.randomnumberapp2;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class MainFragment extends Fragment {
    private TextView textView;
    private View view;

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        view = inflater.inflate(R.layout.mainfragment, null);
        textView = (TextView)view.findViewById(R.id.mainfragment_textview);
        printNumber(MainActivity.mCountNumber);
        return view;
    }

    public void printNumber(int CountNumber){
        textView.setText(Integer.toString(CountNumber));
    }
}